package com.cg.repo;

import org.springframework.data.repository.CrudRepository;


import com.cg.entity.User;

public interface UserRepo extends CrudRepository<User, Integer> {

}
