import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from '../model/login';
import { Patient } from '../model/patientdetails';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  patientArr: Patient[] = [];
  patient: Patient;

  constructor(private router: Router, private service: ServiceService) {
  }

  ngOnInit() {
    this.get();
  }
get() {
  console.log(this.patientArr);
  this.service.getPatient().subscribe( res => {
    this.patientArr = res;
    JSON.stringify(this.patientArr);
    console.log(this.patientArr);
  });
}
}
