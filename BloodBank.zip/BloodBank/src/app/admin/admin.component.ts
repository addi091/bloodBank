import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from '../model/login';
import { Patient } from '../model/patientdetails';
import { ServiceService } from '../service.service';
import { User } from '../model/user';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  patientArr: Patient[] = [];
  patient: Patient;

  userArr: User[] = [];
  user: User;
  patientsData: any = [];
  userData: any = [];
  constructor(private router: Router, private service: ServiceService) {
  }

  ngOnInit() {

    // this.service.getPatient().subscribe( res => {
    //   this.patientArr = res;
    //   JSON.stringify(this.patientArr);
    //   console.log(this.patientArr);
    //   return this.patientArr;
    // });
    this.getPatients();
    this.getUsers();
  }
getPatients() {
  console.log(this.patientArr);
  this.service.getPatient().subscribe( res => {
    this.patientArr = (res) ;
    JSON.stringify(this.patientArr);
    console.log(this.patientArr);
    return this.patientArr;
  });
}

getUsers() {
  this.service.getUser().subscribe( res => {
    this.userArr = res;
    JSON.stringify(this.userArr);
    console.log(this.userArr);
    // return this.userArr;
  });
}

  sendNotification() {
       for (const u of this.userArr) {
        for (const p of this.patientArr) {
         if (p.patientBloodGroup === u.userBloodGroup) {
          alert('Blood Group Matched');
          break;
         }
         else {
           alert('This blood group is not avaliable');
         }
        }
    }
}
}

