export class Login {
    userId: any;
    password: any;
}
