export class User {
 userId: number;
 userName: string;
 userContact: string;
 userEmail: string;
 userBloodGroup: string;

}
