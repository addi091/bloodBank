export class User {
 userId: any;
 userName: any;
 userContact: any;
 userEmail: any;
 userBloodGroup: any;

}
