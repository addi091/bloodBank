import { Component, OnInit } from '@angular/core';
import { Login } from '../model/login';
import { Router } from '@angular/router';
import { setDefaultService } from 'selenium-webdriver/edge';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginArr: Login[] = [];
  login: Login;
  constructor(private router: Router) { 
    this.login = new Login();
  }

  ngOnInit() {
  }

}
