import { Component, OnInit } from "@angular/core";
import { User } from "../model/user";
import { ServiceService } from "../service.service";
import { Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: "app-userregistration",
  templateUrl: "./userregistration.component.html",
  styleUrls: ["./userregistration.component.css"]
})
export class UserregistrationComponent implements OnInit {
  numregex : any;
  userArr: User[] = [];
  user: User;
  allEmailId = [];
  emailCheck: boolean;
  // user: User = new User();
  email = new FormControl('', Validators.required);
   regex = new RegExp('[0-9]');


  constructor(private service: ServiceService, private router: Router) {
    this.user = new User() ;

  }

  ngOnInit() {
    // this.addUser();
  }

  addUser() {
    this.service.addUser(this.user).subscribe(data => {
      console.log(data);
    });
  }

  getUsers() {
    this.service.getUser().subscribe(res => {
      this.userArr = res;
      for (const u of this.userArr) {
        if (this.user.userEmail !== u.userEmail) {
          this.emailCheck = true;
        }
        else {
          this.emailCheck = false;
          alert('user id exists');
          break;
        }

      }
      if (this.emailCheck) {
        this.addUser();
        this.router.navigate(['/admin']);
      }

    });
  }

  // noValidation(no:string) {
  //   if(this.regex.test(no)){
  //     (<HTMLInputElement> document.getElementById("submit")).disabled = true;

  //   }
  // }
}
